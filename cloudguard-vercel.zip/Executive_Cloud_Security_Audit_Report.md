# Executive Cloud Security & GRC Assurance Audit Report
**Assessment Target:** Enterprise Production Cloud Environment (`AWS Account: 123456789012`)  
**Audit Lead:** Nishan Khadgi — Technology Risk & Information Systems Auditor  
**Date of Audit:** October 28, 2026  
**Assessment Tooling:** Prowler v4.0.0 CLI, CloudGuard GRC Mapping Engine, Python Risk Quantifier  
**Frameworks Assessed:** CIS AWS Foundations v3.0 | NIST CSF 2.0 | ISO/IEC 27001:2022 | AICPA SOC 2 (2017 TSC)  

---

## 1. Executive Summary

Internal Audit / Technology Risk Advisory conducted a comprehensive cloud security and technical compliance review of the enterprise AWS production environment. The objective was to evaluate the operational effectiveness of IT General Controls (ITGC), identity boundaries, cryptographic controls, and monitoring mechanisms governing cloud-hosted customer data and financial systems.

A total of **20 cloud configuration findings** were identified and mapped to international cybersecurity control frameworks. The assessment revealed **5 Critical** and **8 High** severity control exceptions requiring immediate remediation by management to mitigate substantial risks of unauthorized administrative access, sensitive data exposure, and compliance penalties.

### Key Audit Metrics
| Metric | Count | Risk Threshold / SLA | Status |
| :--- | :--- | :--- | :--- |
| **Total Findings Identified** | **20** | Target: 0 Critical | ⚠️ Requires Remediation |
| **Critical Severity Gaps** | **5** | 7-Day Remediation SLA | 🔴 Priority 1 Attention |
| **High Severity Gaps** | **8** | 30-Day Remediation SLA | 🟠 Priority 2 Attention |
| **Medium Severity Gaps** | **5** | 60-Day Remediation SLA | 🟡 Priority 3 Attention |
| **Low Severity Gaps** | **2** | 90-Day Remediation SLA | 🔵 Priority 4 Attention |
| **Audit Workpapers Documented** | **20** | Complete GRC Evidence Trail | ✅ Verified |

---

## 2. Findings Breakdown by Cloud Service & Domain

| AWS Service | Total Findings | Primary Risk Vector | Control Framework Impact |
| :--- | :--- | :--- | :--- |
| **IAM** | 6 | Excessive Privilege, Missing Root MFA, Inactive Keys | CIS 1.x, NIST PR.AA, ISO A.5.15, SOC 2 CC6.1 |
| **S3** | 4 | Public Access Risk, Missing Default KMS, Versioning | CIS 2.1, NIST PR.DS, ISO A.8.12, SOC 2 CC6.6 |
| **EC2 / VPC** | 4 | Unrestricted Port 22 SSH, IMDSv1, Flow Logs | CIS 5.x, NIST PR.AC, ISO A.8.20, SOC 2 CC6.6 |
| **CloudTrail** | 2 | Missing S3 Data Event Logging, Digest Integrity | CIS 3.x, NIST DE.AE, ISO A.8.15, SOC 2 CC7.2 |
| **KMS & RDS** | 3 | Unencrypted Storage, Disabled Key Rotation | CIS 2.x, NIST PR.DS, ISO A.8.24, SOC 2 CC6.1 |
| **GuardDuty** | 1 | Disabled Threat Detection in Core Region | CIS 3.4, NIST DE.CM, ISO A.8.16, SOC 2 CC7.2 |

---

## 3. High-Priority Control Exceptions (Critical Deficiencies)

The following control exceptions present immediate operational, regulatory, and reputational risk to the enterprise:

### WP-IAM-001: Root account MFA is not enabled
- **Resource ARN:** `arn:aws:iam::123456789012:root`
- **Inherent Risk Score:** **25 / 25** (Severity: `CRITICAL`)
- **Business Impact:** Catastrophic data breach or root administrative takeover
- **Control Mappings:**
  - **CIS AWS Foundations v3.0:** `CIS 1.5`
  - **NIST CSF 2.0:** `PR.AA-01`
  - **ISO/IEC 27001:2022:** `A.5.15`
  - **AICPA SOC 2:** `CC6.1`
- **Audit Testing Procedure:** Inspect root credential report and verify virtual/hardware MFA serial is active.
- **Remediation Action Required:** Enable a hardware or virtual MFA device immediately on the root user and lock credentials in an enterprise vault.
- **Owner / SLA:** `Cloud IAM SecOps` (Target Due Date: `2026-11-04`)

---

### WP-S3-002: S3 bucket public block access is disabled
- **Resource ARN:** `arn:aws:s3:::customer-pii-analytics-archive-2024`
- **Inherent Risk Score:** **25 / 25** (Severity: `CRITICAL`)
- **Business Impact:** Catastrophic data breach or root administrative takeover
- **Control Mappings:**
  - **CIS AWS Foundations v3.0:** `CIS 2.1.5`
  - **NIST CSF 2.0:** `PR.DS-01`
  - **ISO/IEC 27001:2022:** `A.8.12`
  - **AICPA SOC 2:** `CC6.6`
- **Audit Testing Procedure:** Verify account-level and bucket-level Public Access Block configuration via GetPublicAccessBlock.
- **Remediation Action Required:** Enable all 4 S3 Public Access Block settings and verify bucket ACLs and policies.
- **Owner / SLA:** `Cloud Infrastructure Lead` (Target Due Date: `2026-11-04`)

---

### WP-EC2-003: Security Group allows unrestricted SSH ingress (0.0.0.0/0)
- **Resource ARN:** `arn:aws:ec2:us-east-1:123456789012:security-group/sg-0f72a819b9c02d`
- **Inherent Risk Score:** **25 / 25** (Severity: `CRITICAL`)
- **Business Impact:** Catastrophic data breach or root administrative takeover
- **Control Mappings:**
  - **CIS AWS Foundations v3.0:** `CIS 5.2`
  - **NIST CSF 2.0:** `PR.AC-05`
  - **ISO/IEC 27001:2022:** `A.8.20`
  - **AICPA SOC 2:** `CC6.6`
- **Audit Testing Procedure:** Review ingress rules on all security groups to ensure 0.0.0.0/0 is not allowed on administrative ports.
- **Remediation Action Required:** Remove inbound rule allowing 0.0.0.0/0 on port 22. Enforce AWS Systems Manager Session Manager or dedicated corporate VPN CIDR.
- **Owner / SLA:** `Network Security Engineering` (Target Due Date: `2026-11-04`)

---

### WP-RDS-010: RDS database instance storage encryption is disabled
- **Resource ARN:** `arn:aws:rds:us-east-1:123456789012:db:billing-mysql-primary`
- **Inherent Risk Score:** **25 / 25** (Severity: `CRITICAL`)
- **Business Impact:** Catastrophic data breach or root administrative takeover
- **Control Mappings:**
  - **CIS AWS Foundations v3.0:** `CIS 2.3.1`
  - **NIST CSF 2.0:** `PR.DS-01`
  - **ISO/IEC 27001:2022:** `A.8.24`
  - **AICPA SOC 2:** `CC6.1`
- **Audit Testing Procedure:** Inspect DescribeDBInstances StorageEncrypted attribute and KMS key ARN.
- **Remediation Action Required:** Create snapshot
- **Owner / SLA:** `Database Engineering Team` (Target Due Date: `2026-11-04`)

---

### WP-IAM-011: IAM customer policy contains wildcard AdministratorAccess (*:*)
- **Resource ARN:** `arn:aws:iam::123456789012:policy/ContractorSupportRolePolicy`
- **Inherent Risk Score:** **25 / 25** (Severity: `CRITICAL`)
- **Business Impact:** Catastrophic data breach or root administrative takeover
- **Control Mappings:**
  - **CIS AWS Foundations v3.0:** `CIS 1.16`
  - **NIST CSF 2.0:** `PR.AA-01`
  - **ISO/IEC 27001:2022:** `A.5.15`
  - **AICPA SOC 2:** `CC6.3`
- **Audit Testing Procedure:** Parse customer-managed IAM policies to detect Action=* on Resource=* without conditions.
- **Remediation Action Required:** Replace wildcard policy with least-privilege role definitions scoped to specific resource ARNs.
- **Owner / SLA:** `Cloud IAM SecOps` (Target Due Date: `2026-11-04`)

---

## 4. Remediation SLA & Management Action Plan

| Workpaper Ref | Finding | Owner | Target Due Date | SLA Status |
| :--- | :--- | :--- | :--- | :--- |
| `WP-IAM-001` | Root account MFA is not enabled... | `Cloud IAM SecOps` | `2026-11-04` | `Open (7d SLA)` |
| `WP-S3-002` | S3 bucket public block access is disab... | `Cloud Infrastructure Lead` | `2026-11-04` | `Open (7d SLA)` |
| `WP-EC2-003` | Security Group allows unrestricted SSH... | `Network Security Engineering` | `2026-11-04` | `Open (7d SLA)` |
| `WP-RDS-010` | RDS database instance storage encrypti... | `Database Engineering Team` | `2026-11-04` | `Open (7d SLA)` |
| `WP-IAM-011` | IAM customer policy contains wildcard ... | `Cloud IAM SecOps` | `2026-11-04` | `Open (7d SLA)` |
| `WP-CLOUDTRAIL-004` | CloudTrail S3 data write events are no... | `Security Operations & Logging` | `2026-11-27` | `Open (30d SLA)` |
| `WP-KMS-005` | KMS Customer Managed Key rotation is d... | `Cryptographic Ops Team` | `2026-11-27` | `Open (30d SLA)` |
| `WP-IAM-006` | IAM user active access key unused for ... | `Cloud IAM SecOps` | `2026-11-27` | `Open (30d SLA)` |
| `WP-S3-008` | S3 bucket default server-side encrypti... | `Cloud Infrastructure Lead` | `2026-11-27` | `Open (30d SLA)` |
| `WP-GUARDDUTY-009` | GuardDuty detector is not enabled in a... | `SOC Incident Response Team` | `2026-11-27` | `Open (30d SLA)` |
| `WP-EC2-015` | EC2 default EBS encryption is disabled... | `Cloud Infrastructure Lead` | `2026-11-27` | `Open (30d SLA)` |
| `WP-CLOUDTRAIL-016` | CloudTrail log file integrity validati... | `Compliance & Audit Team` | `2026-11-27` | `Open (30d SLA)` |
| `WP-IAM-018` | IAM console users without MFA attached... | `Cloud IAM SecOps` | `2026-11-27` | `Open (30d SLA)` |
| `WP-EC2-007` | EC2 instance metadata service IMDSv1 a... | `DevOps Platform Team` | `2026-12-27` | `Open (60d SLA)` |
| `WP-VPC-012` | VPC Flow Logs are not enabled for prod... | `Network Security Engineering` | `2026-12-27` | `Open (60d SLA)` |
| `WP-IAM-013` | IAM account password policy length is ... | `Identity Governance Team` | `2026-12-27` | `Open (60d SLA)` |
| `WP-S3-017` | S3 bucket versioning is suspended or d... | `Enterprise Data Governance` | `2026-12-27` | `Open (60d SLA)` |
| `WP-RDS-019` | RDS production database instance is si... | `Database Engineering Team` | `2026-12-27` | `Open (60d SLA)` |
| `WP-S3-014` | S3 audit archive bucket lacks lifecycl... | `Enterprise Data Governance` | `2027-01-26` | `Open (90d SLA)` |
| `WP-IAM-020` | AWS Support role has not been provisio... | `IT Incident Response` | `2027-01-26` | `Open (90d SLA)` |

---

## 5. Professional Disclaimer

*This technical assessment and compliance mapping artifact is published as part of Nishan Khadgi's Professional Technology Risk & IT Audit Portfolio. While control mappings adhere directly to official CIS Benchmark v3.0, NIST CSF 2.0, ISO/IEC 27001:2022, and AICPA SOC 2 criteria, findings and simulated evidence demonstrate audit methodology and do not constitute formal regulatory attestation or certification.*
